﻿' Allows the database defined in the system configuration to be used
Imports System.Configuration
' Allows connection to be established with the connection string and the program
Imports System.Data.OleDb
Public Class ViewRequestReplies

    ' Fills data table with data from the database
    Public connString As String = ConfigurationManager.ConnectionStrings("Computing_NEA.My.MySettings.MongooseGamesConnectionString").ConnectionString
    ' Allows sql statement to be performed on the database
    Public conn As New OleDbConnection(connString)
    ' Defines the data table
    Public StaffReplies As New DataTable

    Private Sub ViewRequestReplies_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Sets data source which will be the function returning the data table
        StaffRepliesDataGridView.DataSource = GetCustomerRequests()

    End Sub

    ' Creates function which returns the table to the staff member
    Private Function GetCustomerRequests() As DataTable
        Using conn
            ' SQL Statement which retrieves all of the replies that have been sent to the logged in customer so that they can be shown to them
            Using cmd As New OleDbCommand("SELECT * FROM StaffActions WHERE (CustUser) = ('" & CustomerLogin.txtUsername.Text & "')", conn)
                ' Opens connection to the database
                conn.Open()
                ' As SELECT statement is being used, reader is used, allows data to be read and sent to the form
                Dim reader As OleDbDataReader = cmd.ExecuteReader()
                ' Loads the reader data into the form
                StaffReplies.Load(reader)
            End Using
        End Using

        ' The function returns the data table
        Return StaffReplies


    End Function

    Private Sub BtnMenu_Click(sender As Object, e As EventArgs) Handles BtnMenu.Click
        ' Hides current form
        Me.Hide()
        ' Shows menu
        CustomerMenu.Show()
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click
        ' Defines variables that will be used to communicate with the database, allowing records to be deleted
        Dim StaffRepliesDataSet As New DataSet
        Dim StaffRepliesDataTable As New DataTable
        ' DataAdapter will be used to allow the SQL statement to communicate with the database
        Dim StaffRepliesDataAdapter As New OleDbDataAdapter
        ' Loads all of the tables from the data set to the data table
        StaffRepliesDataSet.Tables.Add(StaffRepliesDataTable)
        ' Define connection to the data source
        Dim conn As New OleDbConnection(connString)
        ' Opens the connection
        conn.Open()
        ' Fetches all records from the table
        StaffRepliesDataAdapter = New OleDbDataAdapter("SELECT * FROM StaffActions", conn)
        ' Refreshes the rows in the DataGridView to match the database
        StaffRepliesDataAdapter.Fill(StaffRepliesDataTable)
        ' Deletes the datarow
        StaffRepliesDataTable.Rows(0).Delete()
        ' Reconciles the changes made to the database
        Dim cb As New OleDbCommandBuilder(StaffRepliesDataAdapter)
        ' Updates the datatable with changes made
        StaffRepliesDataAdapter.Update(StaffRepliesDataTable)
        ' Refreshes the DataGridView to show changes made
        StaffRepliesDataGridView.DataSource = StaffRepliesDataTable.DefaultView
        ' Closes the connection
        conn.Close()
        ' Informs the customer that the record was deleted successfully
        MessageBox.Show("Record deleted successfully", "Deletion of record successful")
    End Sub
End Class