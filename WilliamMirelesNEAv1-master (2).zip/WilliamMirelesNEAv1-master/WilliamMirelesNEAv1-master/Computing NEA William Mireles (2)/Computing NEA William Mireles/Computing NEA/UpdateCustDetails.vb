﻿' Allows regex expressions to be utilised which can check if an input contains any letters or numbers to aid validation
Imports System.Text.RegularExpressions
Public Class UpdateCustDetails
    Private Sub BtnUpd_Click(sender As Object, e As EventArgs) Handles BtnUpd.Click
        ' If the customerID of the customer they wish to edit their record is empty, or the desired field to be changed is left empty, or the new data to change the field value to is left empty,
        If txtCustID.Text = "" Or FieldName.SelectedItem = "" Or txtNewData.Text = "" Then
            ' The staff member is informed that all text boxes require an input before they can update a customer's details 
            MessageBox.Show("Please ensure that all text boxes are filled before attempting to update a customer's field value", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            ' If the staff member is trying to change a customer's field value that should only be composed of letters, to a value that contains digits,
        ElseIf FieldName.SelectedItem = "FirstName" And Regex.Match(txtNewData.Text, "\d").Success Or FieldName.SelectedItem = "Surname" And Regex.Match(txtNewData.Text, "\d").Success Or FieldName.SelectedItem = "County" And Regex.Match(txtNewData.Text, "\d").Success Or FieldName.SelectedItem = "Town" And Regex.Match(txtNewData.Text, "\d").Success Then
            ' The staff member is informed that they cannot change that customer's field if it contains a digit
            MessageBox.Show("You cannot change a customer's " & FieldName.SelectedItem & " to a value that contains digits ", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtNewData.Clear()

            ' If the staff member is trying to change the phone number of a customer, it checks if the phone number entered is less/more than 11 digits long
        ElseIf FieldName.SelectedItem = "PhoneNum" And txtNewData.Text.Length <> 11 Or FieldName.SelectedItem = "PhoneNum" And IsNumeric(txtNewData.Text) = False Then
            ' If so, they are informed that they need to ensure their phone number exactly 11 characters long
            MessageBox.Show("Please ensure that the phone number is 11 digits long", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' Clears the text box to faciliate re-entering of data
            txtNewData.Clear()

            ' If a staff member is trying to change the Postcode of a customer
            ' It is checked if its 7 or 8 characters long (UK format inc. space)
        ElseIf FieldName.SelectedItem = "Postcode" And txtNewData.Text.Length < 7 Or FieldName.SelectedItem = "Postcode" And txtNewData.Text.Length > 8 Or FieldName.SelectedItem = "Postcode" And txtNewData.Text.Contains(" ") = False Then
            ' If not, they are informed that they need to enter a valid postcode
            MessageBox.Show("Please ensure that your postcode is either 7 or 8 characters long, including a space in between the two parts ", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            ' If the inputs have been validated as per rules above, the customer details can be updated
            ' Create connection to the database
            Dim conn As New System.Data.OleDb.OleDbConnection()
            ' Defines location of the database
            conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
            ' SQL (Structured Query Lanugage) statement which changes the value of the desired field to the desired value in the record of the desired customer
            Dim sql As String = "UPDATE Customers SET " & FieldName.SelectedItem & " = """ & txtNewData.Text & """ WHERE CustomerID = " & txtCustID.Text & ""

            ' Executes the statement against the database
            Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)

            ' Connects the sql statement to the database
            sqlCom.Connection = conn

            ' Opens the connection
            conn.Open()


            ' Staff member is notified of their success of their required task.
            MessageBox.Show("Field value updated", "Database record updation successful")

            ' Carry out the sql statement
            Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

            ' Close the connection to the database
            conn.Close()
        End If

    End Sub

    Private Sub BtnMenu_Click(sender As Object, e As EventArgs) Handles BtnMenu.Click
        ' Hides the current form
        Me.Hide()
        ' Shows the staff menu
        StaffMenu.Show()
    End Sub
End Class