﻿Public Class CustomerMenu
    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click
        ' Hides current form
        Me.Hide()
        ' Redirects desired feature
        Form1.Show()
    End Sub

    Private Sub BtnSendRequest_Click(sender As Object, e As EventArgs) Handles BtnSendRequest.Click
        ' Hides current form
        Me.Hide()
        ' Redirects desired feature
        SendRequest.Show()
    End Sub

    Private Sub BtnViewRequests_Click(sender As Object, e As EventArgs) Handles BtnViewRequests.Click
        ' Hides current form
        Me.Hide()
        ' Redirects desired feature
        ViewRequestReplies.Show()
    End Sub
    Private Sub BtnGameSearch_Click(sender As Object, e As EventArgs) Handles BtnGameSearch.Click
        ' Hides current form
        Me.Hide()
        ' Redirects desired feature
        CustSearchGames.Show()
    End Sub

    Private Sub BtnViewGames_Click(sender As Object, e As EventArgs) Handles BtnViewGames.Click
        ' Hides current form
        Me.Hide()
        ' Redirects desired feature
        CustViewGames.Show()
    End Sub

    Private Sub BtnViewDetails_Click(sender As Object, e As EventArgs) Handles BtnViewDetails.Click
        ' Hides current form
        Me.Hide()
        ' Redirects desired feature
        ViewMyDetails.Show()
    End Sub

    Private Sub BtnUpdateCredentials_Click(sender As Object, e As EventArgs) Handles BtnUpdateCredentials.Click
        ' Hide current form
        Me.Hide()
        ' Redirects desired feature
        ChangeCredentials.Show()
    End Sub
End Class