﻿Public Class StaffMenu
    Private Sub BtnQuotaCalc_Click(sender As Object, e As EventArgs) Handles BtnQuotaCalc.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        QuotaCalculator.Show()
    End Sub

    Private Sub BtnResell_Click(sender As Object, e As EventArgs) Handles BtnResell.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        ResellCalculator.Show()
    End Sub

    Private Sub BtnAddGame_Click(sender As Object, e As EventArgs) Handles BtnAddGame.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        AddOrRemoveGame.Show()
    End Sub

    Private Sub BtnRecentGames_Click(sender As Object, e As EventArgs) Handles BtnRecentGames.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        ViewRecentGames.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles BtnSearchGame.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        StaffSearchGames.Show()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles BtnUpdateDetails.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        UpdateCustDetails.Show()
    End Sub

    Private Sub BtnViewDetails_Click(sender As Object, e As EventArgs) Handles BtnSearchCust.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        ViewCustDetails.Show()
    End Sub

    Private Sub BtnLogout_Click(sender As Object, e As EventArgs) Handles BtnLogout.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        Form1.Show()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        ViewCustomerRequests.Show()
    End Sub

    Private Sub BtnInform_Click(sender As Object, e As EventArgs) Handles BtnInform.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        RequestReply.Show()
    End Sub


    Private Sub BtnViewCustomers_Click(sender As Object, e As EventArgs) Handles BtnViewCustomers.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        ViewAllCustomers.Show()
    End Sub

    Private Sub BtnViewGames_Click(sender As Object, e As EventArgs) Handles BtnViewGames.Click
        ' Hides staff menu
        Me.Hide()
        ' Accesses desired feature
        ViewAllGames.Show()
    End Sub
End Class