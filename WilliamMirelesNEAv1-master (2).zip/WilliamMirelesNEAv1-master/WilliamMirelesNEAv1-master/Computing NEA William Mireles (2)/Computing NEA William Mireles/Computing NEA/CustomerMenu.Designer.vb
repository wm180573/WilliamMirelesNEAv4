﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CustomerMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnViewGames = New System.Windows.Forms.Button()
        Me.BtnViewRequests = New System.Windows.Forms.Button()
        Me.BtnViewDetails = New System.Windows.Forms.Button()
        Me.BtnGameSearch = New System.Windows.Forms.Button()
        Me.BtnUpdateCredentials = New System.Windows.Forms.Button()
        Me.BtnSendRequest = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.BtnLogout = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(69, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(443, 29)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Mongoose Games system for customers"
        '
        'BtnViewGames
        '
        Me.BtnViewGames.Location = New System.Drawing.Point(390, 195)
        Me.BtnViewGames.Name = "BtnViewGames"
        Me.BtnViewGames.Size = New System.Drawing.Size(140, 40)
        Me.BtnViewGames.TabIndex = 4
        Me.BtnViewGames.Text = "View all games currently available"
        Me.BtnViewGames.UseVisualStyleBackColor = True
        '
        'BtnViewRequests
        '
        Me.BtnViewRequests.Location = New System.Drawing.Point(217, 193)
        Me.BtnViewRequests.Name = "BtnViewRequests"
        Me.BtnViewRequests.Size = New System.Drawing.Size(140, 42)
        Me.BtnViewRequests.TabIndex = 9
        Me.BtnViewRequests.Text = "View request replies"
        Me.BtnViewRequests.UseVisualStyleBackColor = True
        '
        'BtnViewDetails
        '
        Me.BtnViewDetails.Location = New System.Drawing.Point(28, 195)
        Me.BtnViewDetails.Name = "BtnViewDetails"
        Me.BtnViewDetails.Size = New System.Drawing.Size(140, 40)
        Me.BtnViewDetails.TabIndex = 10
        Me.BtnViewDetails.Text = "View your details"
        Me.BtnViewDetails.UseVisualStyleBackColor = True
        '
        'BtnGameSearch
        '
        Me.BtnGameSearch.Location = New System.Drawing.Point(390, 138)
        Me.BtnGameSearch.Name = "BtnGameSearch"
        Me.BtnGameSearch.Size = New System.Drawing.Size(140, 40)
        Me.BtnGameSearch.TabIndex = 11
        Me.BtnGameSearch.Text = "Search certain game"
        Me.BtnGameSearch.UseVisualStyleBackColor = True
        '
        'BtnUpdateCredentials
        '
        Me.BtnUpdateCredentials.Location = New System.Drawing.Point(28, 138)
        Me.BtnUpdateCredentials.Name = "BtnUpdateCredentials"
        Me.BtnUpdateCredentials.Size = New System.Drawing.Size(140, 40)
        Me.BtnUpdateCredentials.TabIndex = 12
        Me.BtnUpdateCredentials.Text = "Change credentials"
        Me.BtnUpdateCredentials.UseVisualStyleBackColor = True
        '
        'BtnSendRequest
        '
        Me.BtnSendRequest.Location = New System.Drawing.Point(217, 138)
        Me.BtnSendRequest.Name = "BtnSendRequest"
        Me.BtnSendRequest.Size = New System.Drawing.Size(140, 40)
        Me.BtnSendRequest.TabIndex = 13
        Me.BtnSendRequest.Text = "Send request"
        Me.ToolTip1.SetToolTip(Me.BtnSendRequest, "This button covers sending a buy/sell request, a wishlist request and a quote req" &
        "uest.")
        Me.BtnSendRequest.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(39, 105)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(107, 20)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Personal data"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(225, 105)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 20)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Requests"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(415, 105)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(61, 20)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Games"
        '
        'BtnLogout
        '
        Me.BtnLogout.Location = New System.Drawing.Point(536, 257)
        Me.BtnLogout.Name = "BtnLogout"
        Me.BtnLogout.Size = New System.Drawing.Size(69, 32)
        Me.BtnLogout.TabIndex = 23
        Me.BtnLogout.Text = "Logout"
        Me.BtnLogout.UseVisualStyleBackColor = True
        '
        'CustomerMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(613, 292)
        Me.Controls.Add(Me.BtnLogout)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.BtnSendRequest)
        Me.Controls.Add(Me.BtnUpdateCredentials)
        Me.Controls.Add(Me.BtnGameSearch)
        Me.Controls.Add(Me.BtnViewDetails)
        Me.Controls.Add(Me.BtnViewRequests)
        Me.Controls.Add(Me.BtnViewGames)
        Me.Controls.Add(Me.Label1)
        Me.Name = "CustomerMenu"
        Me.Text = "CustomerMenu"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents BtnViewGames As Button
    Friend WithEvents BtnViewRequests As Button
    Friend WithEvents BtnViewDetails As Button
    Friend WithEvents BtnGameSearch As Button
    Friend WithEvents BtnUpdateCredentials As Button
    Friend WithEvents BtnSendRequest As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents BtnLogout As Button
End Class
