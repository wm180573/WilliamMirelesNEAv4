﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ViewRecentGames
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MongooseGamesDataSet = New Computing_NEA.MongooseGamesDataSet()
        Me.MongooseGamesDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BtnMainMenu = New System.Windows.Forms.Button()
        Me.RecentGamesDataGridView = New System.Windows.Forms.DataGridView()
        CType(Me.MongooseGamesDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MongooseGamesDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RecentGamesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(144, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(504, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "View all games recently transferred in and out of the system"
        '
        'MongooseGamesDataSet
        '
        Me.MongooseGamesDataSet.DataSetName = "MongooseGamesDataSet"
        Me.MongooseGamesDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MongooseGamesDataSetBindingSource
        '
        Me.MongooseGamesDataSetBindingSource.DataSource = Me.MongooseGamesDataSet
        Me.MongooseGamesDataSetBindingSource.Position = 0
        '
        'BtnMainMenu
        '
        Me.BtnMainMenu.Location = New System.Drawing.Point(766, 306)
        Me.BtnMainMenu.Name = "BtnMainMenu"
        Me.BtnMainMenu.Size = New System.Drawing.Size(140, 56)
        Me.BtnMainMenu.TabIndex = 23
        Me.BtnMainMenu.Text = "Return to main menu"
        Me.BtnMainMenu.UseVisualStyleBackColor = True
        '
        'RecentGamesDataGridView
        '
        Me.RecentGamesDataGridView.AllowUserToAddRows = False
        Me.RecentGamesDataGridView.AllowUserToDeleteRows = False
        Me.RecentGamesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.RecentGamesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.RecentGamesDataGridView.Location = New System.Drawing.Point(127, 81)
        Me.RecentGamesDataGridView.Name = "RecentGamesDataGridView"
        Me.RecentGamesDataGridView.ReadOnly = True
        Me.RecentGamesDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.RecentGamesDataGridView.Size = New System.Drawing.Size(572, 244)
        Me.RecentGamesDataGridView.TabIndex = 24
        '
        'ViewRecentGames
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(918, 365)
        Me.Controls.Add(Me.RecentGamesDataGridView)
        Me.Controls.Add(Me.BtnMainMenu)
        Me.Controls.Add(Me.Label1)
        Me.Name = "ViewRecentGames"
        Me.Text = "ViewRecentGames"
        CType(Me.MongooseGamesDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MongooseGamesDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RecentGamesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents MongooseGamesDataSetBindingSource As BindingSource
    Friend WithEvents MongooseGamesDataSet As MongooseGamesDataSet
    Friend WithEvents BtnMainMenu As Button
    Friend WithEvents RecentGamesDataGridView As DataGridView
End Class
