﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ViewCustDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtCustUser = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BtnCustSearch = New System.Windows.Forms.Button()
        Me.TxtCustID = New System.Windows.Forms.TextBox()
        Me.TxtCustName = New System.Windows.Forms.TextBox()
        Me.TxtCustSurname = New System.Windows.Forms.TextBox()
        Me.TxtCustCounty = New System.Windows.Forms.TextBox()
        Me.TxtCustAddress = New System.Windows.Forms.TextBox()
        Me.TxtCustPhone = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TxtCustPostcode = New System.Windows.Forms.TextBox()
        Me.TxtCustTown = New System.Windows.Forms.TextBox()
        Me.BtnMenu = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(163, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(371, 31)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Customer Information Lookup"
        '
        'TxtCustUser
        '
        Me.TxtCustUser.Location = New System.Drawing.Point(294, 97)
        Me.TxtCustUser.Name = "TxtCustUser"
        Me.TxtCustUser.Size = New System.Drawing.Size(154, 20)
        Me.TxtCustUser.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(108, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(157, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Customer username:"
        '
        'BtnCustSearch
        '
        Me.BtnCustSearch.Location = New System.Drawing.Point(504, 90)
        Me.BtnCustSearch.Name = "BtnCustSearch"
        Me.BtnCustSearch.Size = New System.Drawing.Size(133, 32)
        Me.BtnCustSearch.TabIndex = 3
        Me.BtnCustSearch.Text = "Find relevant details"
        Me.BtnCustSearch.UseVisualStyleBackColor = True
        '
        'TxtCustID
        '
        Me.TxtCustID.Location = New System.Drawing.Point(117, 145)
        Me.TxtCustID.Name = "TxtCustID"
        Me.TxtCustID.Size = New System.Drawing.Size(154, 20)
        Me.TxtCustID.TabIndex = 4
        '
        'TxtCustName
        '
        Me.TxtCustName.Location = New System.Drawing.Point(117, 186)
        Me.TxtCustName.Name = "TxtCustName"
        Me.TxtCustName.Size = New System.Drawing.Size(154, 20)
        Me.TxtCustName.TabIndex = 5
        '
        'TxtCustSurname
        '
        Me.TxtCustSurname.Location = New System.Drawing.Point(117, 232)
        Me.TxtCustSurname.Name = "TxtCustSurname"
        Me.TxtCustSurname.Size = New System.Drawing.Size(154, 20)
        Me.TxtCustSurname.TabIndex = 6
        '
        'TxtCustCounty
        '
        Me.TxtCustCounty.Location = New System.Drawing.Point(365, 232)
        Me.TxtCustCounty.Name = "TxtCustCounty"
        Me.TxtCustCounty.Size = New System.Drawing.Size(154, 20)
        Me.TxtCustCounty.TabIndex = 9
        '
        'TxtCustAddress
        '
        Me.TxtCustAddress.Location = New System.Drawing.Point(365, 186)
        Me.TxtCustAddress.Name = "TxtCustAddress"
        Me.TxtCustAddress.Size = New System.Drawing.Size(154, 20)
        Me.TxtCustAddress.TabIndex = 8
        '
        'TxtCustPhone
        '
        Me.TxtCustPhone.Location = New System.Drawing.Point(365, 145)
        Me.TxtCustPhone.Name = "TxtCustPhone"
        Me.TxtCustPhone.Size = New System.Drawing.Size(154, 20)
        Me.TxtCustPhone.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(14, 143)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 20)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "CustomerID"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(14, 184)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 20)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Firstname"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(14, 232)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 20)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Surname"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(276, 232)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(59, 20)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "County"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(276, 184)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 20)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Address"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(276, 143)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(83, 20)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "Phone No."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(548, 184)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(76, 20)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Postcode"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(548, 143)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(47, 20)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Town"
        '
        'TxtCustPostcode
        '
        Me.TxtCustPostcode.Location = New System.Drawing.Point(637, 186)
        Me.TxtCustPostcode.Name = "TxtCustPostcode"
        Me.TxtCustPostcode.Size = New System.Drawing.Size(154, 20)
        Me.TxtCustPostcode.TabIndex = 17
        '
        'TxtCustTown
        '
        Me.TxtCustTown.Location = New System.Drawing.Point(637, 143)
        Me.TxtCustTown.Name = "TxtCustTown"
        Me.TxtCustTown.Size = New System.Drawing.Size(154, 20)
        Me.TxtCustTown.TabIndex = 16
        '
        'BtnMenu
        '
        Me.BtnMenu.Location = New System.Drawing.Point(646, 221)
        Me.BtnMenu.Name = "BtnMenu"
        Me.BtnMenu.Size = New System.Drawing.Size(128, 40)
        Me.BtnMenu.TabIndex = 21
        Me.BtnMenu.Text = "Return to main menu"
        Me.BtnMenu.UseVisualStyleBackColor = True
        '
        'ViewCustDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(796, 270)
        Me.Controls.Add(Me.BtnMenu)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.TxtCustPostcode)
        Me.Controls.Add(Me.TxtCustTown)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtCustCounty)
        Me.Controls.Add(Me.TxtCustAddress)
        Me.Controls.Add(Me.TxtCustPhone)
        Me.Controls.Add(Me.TxtCustSurname)
        Me.Controls.Add(Me.TxtCustName)
        Me.Controls.Add(Me.TxtCustID)
        Me.Controls.Add(Me.BtnCustSearch)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtCustUser)
        Me.Controls.Add(Me.Label1)
        Me.Name = "ViewCustDetails"
        Me.Text = "ViewCustDetails"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents TxtCustUser As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents BtnCustSearch As Button
    Friend WithEvents TxtCustID As TextBox
    Friend WithEvents TxtCustName As TextBox
    Friend WithEvents TxtCustSurname As TextBox
    Friend WithEvents TxtCustCounty As TextBox
    Friend WithEvents TxtCustAddress As TextBox
    Friend WithEvents TxtCustPhone As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents TxtCustPostcode As TextBox
    Friend WithEvents TxtCustTown As TextBox
    Friend WithEvents BtnMenu As Button
End Class
