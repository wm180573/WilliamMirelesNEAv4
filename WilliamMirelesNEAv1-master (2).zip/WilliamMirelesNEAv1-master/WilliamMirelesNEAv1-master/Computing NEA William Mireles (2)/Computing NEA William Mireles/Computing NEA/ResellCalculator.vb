﻿Public Class ResellCalculator
    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles BtnCalculate.Click
        Try
            ' If they enter a price that is not numeric, they are informed that they need to enter a valid value
            If IsNumeric(txtPricePaid.Text) = False Then
                MessageBox.Show("Please ensure that the price paid for the game is a valid number, please try again.", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtPricePaid.Clear()
                ' If they leave the pricepaid textbox blank, they are then informed they are required to give a value
            ElseIf txtPricePaid.Text = "" Then
                MessageBox.Show("Please ensure that you enter the amount that was paid for the game.", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtPricePaid.Clear()
                ' If they enter a price that is negative, they are made aware that this is impossible and are encouraged to enter a valid value
            ElseIf txtPricePaid.Text < 0 Then
                MessageBox.Show("The price paid for the game cannot be negative, please try again.", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtPricePaid.Clear()


            Else
                ' If the input has been successfully validated, the algorithm is then applied to it and used to populate the resell price textbox
                txtResellPrice.Text = txtPricePaid.Text * 1.25
            End If
            ' If an unspecified error occurs, the system is kept from crashing by catching the error, the user is also informed of this occurence
        Catch ex As Exception
            MessageBox.Show("An unknown error has occured.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Hides current form
        Me.Hide()
        ' Shows staff menu
        StaffMenu.Show()
    End Sub
End Class