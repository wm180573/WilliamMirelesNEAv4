﻿' Allows regex commands to be used to identify characters or numbers in inputs to aid validation
Imports System.Text.RegularExpressions
Public Class AccCrea
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Check if any field is empty and if any of them are empty
        If txtPassword.Text = "" Or txtUsername.Text = "" Or txtFirstName.Text = "" Or txtSurname.Text = "" Or txtTelephone.Text = "" Or txtAddress.Text = "" Or txtCounty.Text = "" Or txtTown.Text = "" Or txtPostcode.Text = "" Then
            ' If so, then the user is notified of this and they are to then fill them in
            MessageBox.Show("Please complete all required fields...", "Authentication Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' Checks if the password is the same as the username
        ElseIf txtUsername.Text = txtPassword.Text Then
            ' If so, user is then to ensure that their username differs from their password
            MessageBox.Show("Please ensure that your username is different from your password", "Security warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' Clears the text boxes to faciliate re-entering of data
            txtUsername.Clear()
            txtPassword.Clear()
            ' Checks if the length of the customer's username or password is less than 5
        ElseIf txtUsername.Text.Length < 5 Or txtPassword.Text.Length < 5 Then
            ' If so, they are prompted to make their username/password longer than 5 characters so that their credentials are more sophisticated
            MessageBox.Show("Please ensure that your username/password is longer than 5 characters", "Security warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' Clears the text boxes to faciliate re-entering of data
            txtUsername.Clear()
            txtPassword.Clear()
            ' Checks if the phone number entered is less/more than 11 digits long
        ElseIf txtTelephone.Text.Length <> 11 Or IsNumeric(txtTelephone.Text) = False Then
            ' If so, they are informed that they need to ensure their phone number exactly 11 characters long
            MessageBox.Show("Please ensure that your phone number is 11 digits long", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' Clears the text box to faciliate re-entering of data
            txtTelephone.Clear()
            ' Checks if the postcode entered is 7 or 8 characters long and if it contains a space
        ElseIf txtPostcode.Text.Length < 7 Or txtPostcode.Text.Length > 8 Or txtPostcode.Text.Contains(" ") = False Then
            ' If not, they are informed that they need to enter a valid postcode
            MessageBox.Show("Please ensure that your postcode is either 7 or 8 characters long, including a space in between the two parts ", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ' Checks if any field which shouldn't be composed of digits e.g. firstname contains any digits
        ElseIf Regex.Match(txtFirstName.Text, "\d").Success Or Regex.Match(txtSurname.Text, "\d").Success Or Regex.Match(txtCounty.Text, "\d").Success Or Regex.Match(txtTown.Text, "\d").Success Then
            ' If so, they are prompted to reevaluate this
            MessageBox.Show("Please ensure that there are no numbers in fields which don't require them", "Validation error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Else

            ' Define new connection
            Dim conn As New System.Data.OleDb.OleDbConnection()
            ' Define database location
            conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ipr0z\OneDrive\Desktop\MongooseGames.accdb"
            ' Find records that have the same username as someone else on the system
            Dim sqlValidation As String = "SELECT * FROM Customers WHERE CustUser='" & txtUsername.Text & "'"
            ' Allows sql to communicate with database
            Dim sqlComValidation As New System.Data.OleDb.OleDbCommand(sqlValidation)
            ' Connect SQL statement to database
            sqlComValidation.Connection = conn
            'Open Database Connection
            conn.Open()
            ' Executes SQL statement against database
            Dim sqlReadValidation As System.Data.OleDb.OleDbDataReader = sqlComValidation.ExecuteReader()

            ' If username is already in use
            If sqlReadValidation.Read() Then
                ' User is notified that username is already in use and they must change it
                MsgBox("Username is already in use, please try another one")

            Else
                ' Inserts all of the information that the user inputs into the database
                Dim sqlInsert As String = "INSERT INTO customers (CustUser,CustPass,FirstName,Surname,PhoneNum,Address,County,Town,Postcode) VALUES ('" & txtUsername.Text & "', '" & txtPassword.Text & "', '" & txtFirstName.Text & "', '" & txtSurname.Text & "', '" & txtTelephone.Text & "', '" & txtAddress.Text & "', '" & txtCounty.Text & "', '" & txtTown.Text & "', '" & txtPostcode.Text.ToUpper & "')"
                ' Allows SQL statement to communicate with databasde
                Dim sqlCom As New System.Data.OleDb.OleDbCommand(sqlInsert)
                ' They are then informed of their account creation
                MessageBox.Show("Account Created, and details saved, you will now be redirected to the login screen", "Account creation successful")
                ' Current form hidden
                Me.Hide()
                ' Directed to the customer login form to now use their newly created credentials to gain access to the system
                CustomerLogin.Show()


                'Connects SQL statement with database
                sqlCom.Connection = conn

                ' Executes SQL statement
                Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()

                ' Closes connection
                conn.Close()
            End If
        End If
    End Sub
End Class